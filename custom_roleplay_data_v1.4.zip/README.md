# custom_roleplay_data
 A datapack that allows you to easily change the CustomModelData of items to change the look of items using resource packs.
 To change the model data of an item stack in the player's mainhand:

 /trigger CustomModelData set <model data #>
 You can change the XP required cost of this action by doing:
 /function custom_roleplay_data:admin
 to access the admin menu or by using the command:
 /scoreboard players set #min_level crd_xp_dummy <level>

 Please note that this datapack will require a custom resource pack to function properly!
